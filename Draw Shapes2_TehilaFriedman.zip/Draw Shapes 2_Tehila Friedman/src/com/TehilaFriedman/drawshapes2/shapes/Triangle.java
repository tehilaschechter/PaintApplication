package com.TehilaFriedman.drawshapes2.shapes;

import java.awt.Color;
import java.awt.Graphics;

public class Triangle extends BoundedShape
{
   public Triangle()
   {
      super();
   }
   
   public Triangle(int x1, int y1, int x2, int y2, Color color, boolean isFilled)
   {
      super(x1, y1, x2, y2, color, isFilled);
   }
   
   @Override
   public void draw(Graphics g)
   {
      g.setColor(getColor());
      
      if (isFilled())
         g.fillPolygon(new int[] {getX1(), getX2(), (getX2() - (getX2() - getX1()))}, new int[] {getY1(), getY2(), getY2()}, 3);
      else
         g.drawPolygon(new int[] {getX1(), getX2(), (getX2() - (getX2() - getX1()))}, new int[] {getY1(), getY2(), getY2()}, 3);
   }

}
